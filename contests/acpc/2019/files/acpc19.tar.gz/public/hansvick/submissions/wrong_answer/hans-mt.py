h, d, m = map(int, input().split())
mags = sorted([int(x) for x in input().split()], reverse=True)

print(sum(mags[:min(len(mags), h // d)]))
