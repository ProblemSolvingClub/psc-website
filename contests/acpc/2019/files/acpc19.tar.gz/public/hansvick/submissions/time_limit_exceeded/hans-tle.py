from itertools import combinations
from math import ceil

h, d, m = map(int, input().split())
mags = [int(x) for x in input().split()]

print(
    max([
        sum(comb) for comb in combinations(mags, min(len(mags), ceil(h / d)))
    ]))
