# trash code, but I'm lazy

import os

s = 'python3 ../../submissions/accepted/hightable-ah.py < hightable-{0}.in > hightable-{0}.ans'
s_eq = 'python3 ../../submissions/accepted/hightable-ah.py < hightable-eq-{0}.in > hightable-eq-{0}.ans'
s_eqs = 'python3 ../../submissions/accepted/hightable-ah.py < hightable-eq-s-{0}.in > hightable-eq-s-{0}.ans'

for i in range(20):
    istr = '{:02}'.format(i + 1)
    t = s.format(istr)
    print(t)
    os.system(t)

for i in range(5):
    istr = '{:02}'.format(i + 1)
    t = s_eq.format(istr)
    print(t)
    os.system(t)

for i in range(5):
    istr = '{:02}'.format(i + 1)
    t = s_eqs.format(istr)
    print(t)
    os.system(t)
