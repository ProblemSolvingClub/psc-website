n, m = list(map(int, input().split()))

c = []
d = []
for _ in range(n):
    c.append([])
    d.append(False)
for i in range(n - 1):
    x = int(input())
    c[x].append(i + 1)
q = []
for _ in range(m):
    x = int(input())
    d[x] = True
    q.append(x)

if m > n - m:
    print('We are NYC.')
elif m < n - m:
    print('We are High Table.')
else:
    print('I\'d say the odds are about even.')
