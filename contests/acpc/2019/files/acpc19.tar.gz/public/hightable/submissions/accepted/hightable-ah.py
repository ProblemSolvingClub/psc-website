n, m = list(map(int, input().split()))

c = []
d = []
for _ in range(n):
    c.append([])
    d.append(False)
for i in range(n - 1):
    x = int(input())
    c[x].append(i + 1)
q = []
for _ in range(m):
    x = int(input())
    d[x] = True
    q.append(x)
idx = 0
ans = 0
while idx < len(q):
    ans += 1
    v = q[idx]
    cs = c[v]
    for cd in cs:
        if not d[cd]:
            d[cd] = True
            q.append(cd)
    idx += 1
if ans > n - ans:
    print('We are NYC.')
elif ans < n - ans:
    print('We are High Table.')
else:
    print('I\'d say the odds are about even.')


