#include <bits/stdc++.h>
using namespace std;
typedef long long LL;

int getidx(unordered_map<string, int>& m, string const& s) {
	auto it = m.find(s);
	if (it != m.end()) return it->second;
	int a = (int)m.size();
	m[s] = a;
	return a;
}

int main() {
	ios_base::sync_with_stdio(false);
	unordered_map<string, int> nmap, imap;
	vector<unordered_set<int>> interests;
	int N, Q;
	cin >> N;
	for (int n = 0; n < N; n++) {
		string name, interest;
		cin >> name >> interest;
		int idxn = getidx(nmap, name);
		int idxi = getidx(imap, interest);
		while (interests.size() <= idxn) interests.emplace_back();
		interests[idxn].insert(idxi);
	}
	cin >> Q;
	unordered_map<LL, bool> cache;
	for (int q = 0; q < Q; q++) {
		string name1, name2;
		cin >> name1 >> name2;
		int idx1 = nmap[name1], idx2 = nmap[name2];
		LL cachekey = idx1*1000000LL + idx2;
		auto it = cache.find(cachekey);
		bool result = false;
		if (it != cache.end()) {
			result = it->second;
		} else {
			const auto *s1 = &interests[idx1];
			const auto *s2 = &interests[idx2];
			for (int interest : *s1) {
				if (s2->count(interest)) {
					result = true;
					break;
				}
			}
			cache[cachekey] = result;
		}
		cout << (result ? "Yes\n" : "No\n");
	}
}
