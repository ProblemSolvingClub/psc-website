#!/usr/bin/python3
import collections
N = int(input())
interests = collections.defaultdict(set)
for n in range(N):
    name, interest = input().split()
    interests[name].add(interest)
Q = int(input())
cache = {}
for q in range(Q):
    name1, name2 = input().split()
    if name1 > name2:
        name1, name2 = name2, name1
    if (name1, name2) in cache:
        result = cache[(name1, name2)]
    else:
        st1 = interests[name1]
        st2 = interests[name2]
        if len(st1) > len(st2):
            st1, st2 = st2, st1
        result = False
        for interest in st1:
            if interest in st2:
                result = True
                break
        cache[(name1, name2)] = result
    print('Yes' if result else 'No')
