import java.util.*;

public class Zionshaheed{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        input.nextLine();

        int sum = 0;

        for (int i = 0; i < n; i++){
            String line = input.nextLine();

            String[] split = line.split(" ");
            int minorSum = 0;
            String sku = split[0];
            minorSum += Character.getNumericValue(sku.charAt(sku.length()-1)); 
            minorSum += Character.getNumericValue(sku.charAt(sku.length()-2)); 
            minorSum += Character.getNumericValue(sku.charAt(sku.length()-3)); 

            if (minorSum % 5 == 0){
                sum += (Integer.parseInt(split[1]))/2;
            }
        }
        System.out.println(sum);

    }
}
