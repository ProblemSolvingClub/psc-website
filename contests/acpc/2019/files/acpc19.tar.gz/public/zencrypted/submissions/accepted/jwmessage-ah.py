n, m = list(map(int, input().split()))
s = input()

if m == 0:
    print(s)
    exit(0)

ks = []
for _ in range(m):
    x, y = list(map(int, input().split()))
    ks.append((x, y))
ks.sort()

for i in range(m - 1):
    k = ks[i]
    ks[i] = (k[0], ks[i + 1][0], k[1])
ks[-1] = (ks[-1][0], n, ks[-1][1])

ks = [(c,a,b) for (a,b,c) in ks]
ks.sort()
ans = ''.join(s[a:b] for _,a,b in ks)
print(ans)
