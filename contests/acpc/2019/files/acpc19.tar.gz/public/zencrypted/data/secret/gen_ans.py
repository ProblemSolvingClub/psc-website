# trash code, but I'm lazy

import os

s = 'python3 ../../submissions/accepted/jwmessage-ah.py < jwmessage-{0}.in > jwmessage-{0}.ans'

for i in range(20):
    istr = '{:02}'.format(i + 1)
    t = s.format(istr)
    print(t)
    os.system(t)